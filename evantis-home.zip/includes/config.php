<?php
// Evantis Home - Configuration File

// Error Reporting (Production'da kapatılmalı)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'evantish_mert');
define('DB_PASS', 'MeRt06-+');
define('DB_NAME', 'evantish_ahmet');

// Site Configuration
define('SITE_NAME', 'Evantis Home');
define('SITE_URL', 'https://evantishome.com');
define('SITE_EMAIL', 'info@evantishome.com');
define('SITE_PHONE', '0555 123 45 67');

// Paths
define('ROOT_PATH', dirname(__DIR__));
define('UPLOAD_PATH', ROOT_PATH . '/uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');

// Pagination
define('PRODUCTS_PER_PAGE', 12);

// Image Settings
define('MAX_IMAGE_SIZE', 5242880); // 5MB
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp']);

// Session Start
session_start();

// Database Connection
try {
    $db = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch(PDOException $e) {
    die("Veritabanı bağlantı hatası: " . $e->getMessage());
}

// Timezone
date_default_timezone_set('Europe/Istanbul');
?>
